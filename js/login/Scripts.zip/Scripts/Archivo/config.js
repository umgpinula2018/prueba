var tenant = 'Florida1';
var clientId = 'fa57ccdb-f8ee-4fd5-8822-42e7e707113b';